import React from 'react';

function App() {
  return (
    <div>
      <h1>Global Leaders Dating App</h1>
      <p>Welcome to the world of legendary leaders!</p>
    </div>
  );
}

export default App;